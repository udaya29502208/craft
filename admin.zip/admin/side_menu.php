
<div class="sidebar content-box" style="display: block;" >
                <ul class="nav">
                    <!-- Main menu -->
                    <li class="current"><a href="home.php"><i class="glyphicon glyphicon-home"></i> Home</a></li>
                    <!--
                    <li><a href="calendar.html"><i class="glyphicon glyphicon-calendar"></i> Calendar</a></li>
                     
                    <li><a href="stats.html"><i class="glyphicon glyphicon-stats"></i> Statistics (Charts)</a></li>
                    <li><a href="tables.html"><i class="glyphicon glyphicon-list"></i> Tables</a></li>
                    <li><a href="buttons.html"><i class="glyphicon glyphicon-record"></i> Buttons</a></li>
                    <li><a href="editors.html"><i class="glyphicon glyphicon-pencil"></i> Editors</a></li>
                    <li><a href="forms.html"><i class="glyphicon glyphicon-tasks"></i> Forms</a></li>-->
             				<li><a href="category.php"><i class="glyphicon glyphicon-tasks"></i>Category</a></li>
                     		<li><a href="portfolio.php"><i class="glyphicon glyphicon-tasks"></i>Products</a></li>
                            <li><a href="testimonial.php"><i class="glyphicon glyphicon-tasks"></i>Services</a></li>
                            <li><a href="testimonial.php"><i class="glyphicon glyphicon-tasks"></i>Contact</a></li>
                          
                			<li><a href="newuser.php"><i class="glyphicon glyphicon-tasks"></i>New Admin</a></li>
                            <li><a href="changepass.php"><i class="glyphicon glyphicon-tasks"></i>Change Password</a></li>
                             <li><a href="admin_career.php"><i class="glyphicon glyphicon-tasks"></i>Contact</a></li>
                            <li><a href="logout.php"><i class="glyphicon glyphicon-tasks"></i>Logout</a></li>
                
                     
                </ul>
             </div>
